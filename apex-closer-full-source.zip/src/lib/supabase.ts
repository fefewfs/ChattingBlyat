import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
  global: {
    headers: { 'X-Client-Info': 'apex-closer-os' },
  },
});

export async function checkSupabaseConnection(): Promise<{ ok: boolean; detail: string }> {
  try {
    const url = `${supabaseUrl}/auth/v1/health`;
    const resp = await fetch(url, {
      headers: { apikey: supabaseAnonKey },
      signal: AbortSignal.timeout(8000),
    });
    if (resp.ok) return { ok: true, detail: 'Supabase Auth доступен' };
    return { ok: false, detail: `Auth health вернул HTTP ${resp.status}` };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return { ok: false, detail: `Не удалось подключиться к Supabase: ${msg}` };
  }
}
